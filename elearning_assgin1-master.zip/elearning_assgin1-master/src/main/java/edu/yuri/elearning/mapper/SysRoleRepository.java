package edu.yuri.elearning.mapper;

import edu.yuri.elearning.entity.SysRole;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SysRoleRepository extends JpaRepository<SysRole, Integer> {
}
