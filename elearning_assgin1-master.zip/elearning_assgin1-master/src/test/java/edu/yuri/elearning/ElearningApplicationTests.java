package edu.yuri.elearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElearningApplicationTests {

    @Test
    void contextLoads() {
    }

}
